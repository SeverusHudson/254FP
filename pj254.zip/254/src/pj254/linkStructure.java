package pj254;


/**
 * Finished by Henry Zhang on July 4th, 2020
 * @author HenryZ
 * Mainly rebuild a linked list structure for linked list priority queue
 */

public class linkStructure {
	
	/**
	 * I need to rewrite the linked list structure
	 */
	
	private String element;
	
	private int priority;
	
	private linkStructure next;
	
	/**
	 * Default constructor
	 */
	
	public linkStructure() {
		
		this.setElement("");
		
		this.setP(-1);
		
		this.setNext(null);
		
	}
	
	public linkStructure(String e, int num) {
		
		this.setElement(e);
		
		this.setP(num);
		
		this.setNext(null);
		
	}
	
	/**
	 * Methods of set and get
	 */
	
	public void setNext(linkStructure head) {
		
		this.next = head;
		
	}
	
	public void setElement(String e) {
		
		this.element = e;
		
	}
	
	public void setP(int num) {
		
		this.priority = num;
		
	}
	
	public linkStructure getNext() {
		
		return next;
		
	}
	
	public String getElement() {
		
		return element;
		
	}
	
	public int getP() {
		
		return priority;
		
	}

}
