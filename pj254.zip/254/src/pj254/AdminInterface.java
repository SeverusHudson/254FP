package pj254;

/**
 * Finished by Henry Zhang on Aug 21, 2020
 */

import java.util.*;
import java.util.concurrent.TimeUnit;

public class AdminInterface {
	
	public static void main(String[] args) {
	
		/**
		 * Here is the bidding system admin interface
		 * This interface will ask admin to enter the bidder name and their initial price manually into the system.
		 * Yes, manually, because we are hard-coding guys. And then, admin will set a OBO or time which will indicate
		 * the end of bidding activities. 
		 * Once user is in the bidding pool, system will automatically bid for user.
		 */
		
		
		/**
		 * Built-in system functionality
		 */
		
		int numOfBidder = 0;
	
		bidderPool bidsystem = new bidderPool();
		
		Scanner userInput = new Scanner(System.in);
		
		int hit = 0;
		/**
		 * Preset the number of total bidder this round.
		 */
		
		System.out.println("Please enter the target price for this item: \n");
		
		hit = userInput.nextInt();
		
		/**
		 * Now system could have customized number of bidder in a single pool
		 */
		
		System.out.println("Please enter the number of bidder this time: \n");
		
		numOfBidder = userInput.nextInt();
		
		String[] userName = new String[numOfBidder];
		
		int[] userPrice = new int[numOfBidder];
		
		
		
		/**
		 * Now we need a while loop to let admin enter all required information
		 */
		
		for(int i=0; i<numOfBidder; i++) {
			
			System.out.println("The name of the bidder: \n");
			
			userInput.nextLine();
			
			userName[i] = userInput.nextLine();
			
			System.out.println("The base price of " + userName[i] + ": (Integer ONLY) \n");
			
			userPrice[i] = userInput.nextInt();
					
		}
		
		/**
		 * Now system will shows admin the current initial status of bidder pool.
		 */
		
		System.out.print("Bidding in process");
		
		/**
		 * Now we generate random number between 1 to 10 and add to each bidder's current price
		 */
		
		Random rand = new Random();
		
		int addPrice = 0;
		
		int min = 1;
		
		int max = 10;
		
		/**
		 * Each bidding will round 100 times.
		 */
		for(int k=0; k<numOfBidder; k++) {
		
			for(int j=0; j<100; j++) {
			
				addPrice = (int)Math.random()*(max-min+1)+1;
			
				userPrice[k] += addPrice;
			
			}
			
			if(userPrice[k]<hit) {
				
				System.out.println("\n(Winner will not meet the cut.) \n");
				
			}
			
			bidsystem.enqueue(userName[k], userPrice[k]);
			
		}
		
		
        try {
        	
            for (int i=0; i<10 ; i++) {
            	
            	/**
            	 * We let cpu to put thread to sleep for 5 second. (loop 10 times but with 500 millisecond each loop.)
            	 */
            	
                Thread.sleep(500);
                
                System.out.print(".");
                
            }
            
        } catch (InterruptedException ex){
        	
            Thread.currentThread().interrupt();
            
        }
        
        System.out.println("\n");
		
		System.out.println("Winner is " + bidsystem.peek() + " !\n");

	
	}

}
