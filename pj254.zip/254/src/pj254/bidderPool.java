package pj254;

/**
 * Bidder Pool
 * @author HenryZ
 * This is the bidder pool, which bidder will enter their name and price in our priority queue
 * The bidder's price will be use as key, the higher the price, the higher the priority. 
 */

public class bidderPool {
	
private linkStructure head;
	
	/**
	 * Now creating the default constructor
	 */
	
	public bidderPool() {
		
		this.head = null;
		
	}
	
	/**
	 * Check if the queue is empty or not
	 */
	
	public boolean isEmpty() {
		
		if(this.head == null) {
			
			return true;
			
		}
		
		return false;
		
	}
	
	/**
	 * Check if the queue is full
	 */
	
	public boolean isFull() {
		
		/**
		 * Linked List will never full unless run of memory
		 */
		
		return false;
		
	}
	
	/**
	 * Return the size of queue
	 */
	
	public int getSize() {
		
		int size = 0;
		
		/**
		 * We create a pointer to point to the head of queue
		 * And then we go from there.
		 */
		
		linkStructure current = this.head;
		
		while(current!=null) {
			
			size++;
			
			current = current.getNext();
			
		}
		
		return size;
		
	}
	
	/**
	 * Peek function that will return the head but not remove it
	 */
	
	public String peek() {
		
		linkStructure current = this.head;
		
		if(current == null) {
			
			return "";
			
		}else {
			
			String element = "";
			
			element = this.head.getElement();
			
			return element;
			
		}
		
	}
	
	/**
	 * Now need to create the enqueue method
	 * In this method, I create each node that will contain element and priority number
	 * And then insert the node into the linked list.
	 * Each time user input the new node, using getP to get the previous priority number
	 * And compare with the new key. Using loop, if it is small, then insert ahead of current node
	 * Until it is smaller.
	 */
	
	public void enqueue(String e, int key) {
		
		/**
		 * First, we need to check if it is the first input or not
		 */
		
		linkStructure node = new linkStructure(e, key);
		
		if(head == null) {
			
			node.setNext(head);
			
			head = node;
			
		}else {
			
			/**
			 * Now we compare the key with previous key
			 */
			
			if(head.getP()<key) {
				
				node.setNext(head);
				
				head = node;
				
			}else {
				
				linkStructure current = this.head;
				
				linkStructure previous = null;
				
				boolean isSmall = false;
				
				while(current!=null) {
					
					if(current.getP()<key) {
						
						node.setNext(current);
						
						previous.setNext(node);
						
						isSmall = true;
						
						break;
						
					}
					
					previous = current;
					
					current = current.getNext();
					
				}
				
				if(isSmall == false) {
					
					previous.setNext(node);
					
				}
				
			}
			
		}
		
	}
	
	/**
	 * Now create the dequeue method
	 */
	
	public String dequeue() {
		
		/**
		 * Create a new pointer point to the head
		 */
		
		linkStructure current = this.head;
		
		/**
		 * If head if null, mean it is empty
		 */
		
		if(current == null) {
			
			return "";
			
		}else {
			
			String element = "";
			
			/**
			 * Otherwise, store the head element first, then remove it from the queue
			 */
			
			element = this.head.getElement();
			
			this.head = this.head.getNext();
			
			return element;
			
		}
		
	}
	
	/**
	 * Display method
	 */
	
	public void display() {
		
		linkStructure current = this.head;
		
		String[] temp = new String[6];
		
		int i=0;
		
		while(current!=null) {
			
			temp[i] = current.getElement();
			
			i++;
			
			current = current.getNext();
			
		}
		
		for(int j=i-1; j>-1; j--) {
			
			System.out.println(temp[j]);
			
		}
		
		System.out.println("\n");
		
	}
	
	/**
	 * Just for default one
	 */
	
	public void displayDefault() {
		
		linkStructure current = this.head;
		
		while(current!=null) {
			
			System.out.println(current.getElement());
			
			current = current.getNext();
			
		}
		
	}

}
